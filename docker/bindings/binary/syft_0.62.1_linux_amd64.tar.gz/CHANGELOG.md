# Changelog

## [v0.62.1](https://github.com/anchore/syft/tree/v0.62.1) (2022-11-21)

[Full Changelog](https://github.com/anchore/syft/compare/v0.62.0...v0.62.1)

### Added Features

- syft fails to resolve npm package aliases [[Issue #1314](https://github.com/anchore/syft/issues/1314)]


